jQuery(document).ready(function ($) {
    $('.form-element').hover(
        function () {
            $(this).find('.use-element').show();
        },
        function () {
            $(this).find('.use-element').hide();
        }
    );

    $('.use-element').on('click', function (e) {
        e.preventDefault();
        var element = $(this).data('type');
        var formBuilder = $('.form-builder');
        console.log(element);

        if (element === 'title') {
            //! get the number of title from the formbuilder
            var titleCount = formBuilder.find('.form-title').length;
            var title = '<div class="form-group form-title" id="form-title-' + (titleCount + 1) + '"><h2>Title ' + (titleCount + 1) + '</h2><input type="text" class="form-control" placeholder="Title"></div>';
            formBuilder.append(title);
        }
    });

    $(document).on('click', '.form-title', function () {
        var titleId = $(this).attr('id');
        var titleNumber = titleId.split('-').pop();
        let titleText = $(this).html() ? $(this).html() : 'Title ' + titleNumber;
        let selectedSize = $(this).hasClass('small') ? 'small' : $(this).hasClass('medium') ? 'medium' : $(this).hasClass('large') ? 'large' : '';
        let selectedClass = $(this).attr('class');
        selectedClass = selectedClass.replace('form-group', '').trim();
        selectedClass = selectedClass.replace('form-title', '').trim();
        selectedClass = selectedClass.replace(selectedSize, '').trim();
        
        console.log('Clicked on Title ' + titleNumber);
        let selectedLayout = $(this).parent('.cfformselement').parent('.cfformspage').attr('class');
        selectedLayout = selectedLayout.replace('cfformspage', '').trim();
        selectedLayout = selectedLayout.replace(/\bpage-\S+/g, '').trim();
        var modalHtml = '';
        // Create modal HTML
        modalHtml = `
            <div class="modal fade" id="titleModal" tabindex="-1" role="dialog" aria-labelledby="titleModalLabel" aria-hidden="true" data-type="title">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="titleModalLabel">Edit Title ${titleNumber}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="titleText">Label</label>
                                    <input type="text" class="form-control" id="titleText" value="${titleText}">
                                </div>
                                <div class="form-group">
                                    <label for="fieldSize">Field Size</label>
                                    <select class="form-control" id="fieldSize">
                                        <option value="small" ${selectedSize === 'small' ? 'selected' : ''}>Small</option>
                                        <option value="medium" ${selectedSize === 'medium' ? 'selected' : ''}>Medium</option>
                                        <option value="large" ${selectedSize === 'large' ? 'selected' : ''}>Large</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="cssClass" class="control-label col-form-label cssClasses">
                                        CSS Classes
                                    </label>
                                    <input type="text" class="form-control" id="cssClass" value="${selectedClass}">
                                </div>
                                <div class="form-group" style="display: none;">
                                    <label for="layoutClass" class="control-label col-form-label layoutClasses">
                                        Layout Classes
                                        <a href="#" class="toggle-layout-selector-display toggle-unfoldable-cont"><i class="fa fa-th-large"></i><span>Show Layouts</span></a>
                                        <a href="#" class="toggle-layout-selector-display toggle-foldable-cont" style="display: none;"><i class="fa fa-th-large"></i><span>Hide Layouts</span></a>
                                    </label>
                                    <input type="text" class="form-control" id="layoutClass" value="${selectedLayout}" readonly>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary saveChanges" data-title-id="${titleNumber}">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#titleModal').remove();

        // Append the new modal to body
        $('body').append(modalHtml);

        // Show the modal
        $('#titleModal').modal('show');
    });

    $(document).on('click', '.toggle-foldable-cont', function (event) {
        event.preventDefault();
        $(this).hide();
        $('.toggle-unfoldable-cont').show();
        $('.unfoldable-cont').remove();
    });

    $(document).on('click', '.toggle-unfoldable-cont', function (event) {
        event.preventDefault();
        let parentElement = $(this).parent().parent('.form-group');

        let htmlElement = `
        <div class="layout-selector-display unfoldable-cont" style="display: block">
            <p class="heading">Select your layout</p>
            <div class="layouts">
                <div class="layout-selector-display-layout">
                <span
                    class="one-half"
                    data-classes="cfforms-one-half cfforms-first"
                ></span
                ><span class="one-half" data-classes="cfforms-one-half"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="one-third"
                    data-classes="cfforms-one-third cfforms-first"
                ></span
                ><span class="one-third" data-classes="cfforms-one-third"></span
                ><span class="one-third" data-classes="cfforms-one-third"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="one-fourth"
                    data-classes="cfforms-one-fourth cfforms-first"
                ></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="one-third"
                    data-classes="cfforms-one-third cfforms-first"
                ></span
                ><span class="two-third" data-classes="cfforms-two-thirds"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="two-third"
                    data-classes="cfforms-two-thirds cfforms-first"
                ></span
                ><span class="one-third" data-classes="cfforms-one-third"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="one-fourth"
                    data-classes="cfforms-one-fourth cfforms-first"
                ></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span
                ><span class="two-fourth" data-classes="cfforms-two-fourths"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="two-fourth"
                    data-classes="cfforms-two-fourths cfforms-first"
                ></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span>
                </div>
                <div class="layout-selector-display-layout">
                <span
                    class="one-fourth"
                    data-classes="cfforms-one-fourth cfforms-first"
                ></span
                ><span class="two-fourth" data-classes="cfforms-two-fourths"></span
                ><span class="one-fourth" data-classes="cfforms-one-fourth"></span>
                </div>
            </div>
            </div>

        `;

        parentElement.append(htmlElement);
        $(this).hide();
        $('.toggle-foldable-cont').show();
    });

    //! left from here hasnain
    $(document).on('click', '.layout-selector-display-layout', function () {
        let parent = $(this).parent('.layouts');
        var thisHtml = $(this).html();
        parent.html('');
        let layoutColumn = document.createElement('div');
        layoutColumn.className = 'layout-selector-display-columns';
        layoutColumn.innerHTML = thisHtml;
        parent.append(layoutColumn);
    });

    $(document).on('click', '.layout-selector-display-columns span', function () {
        let thisClass = $(this).attr('data-classes');
        console.log('Clicked on 1/2', thisClass);
        $('#layoutClass').val(function(index, currentValue) {
            const unwantedClasses = [
                "cfforms-one-half",
                "cfforms-first",
                "cfforms-one-third",
                "cfforms-one-fourth",
                "cfforms-two-thirds",
                "cfforms-two-fourths"
            ];
            
            // New class to add
            let newClass = 'newClass';
        
            // Remove unwanted classes from the current value
            unwantedClasses.forEach(className => {
                currentValue = currentValue.replace(new RegExp("\\b" + className + "\\b", "gi"), "");
            });
        
            // Clean up extra spaces
            currentValue = currentValue.replace(/\s\s+/g, " ").trim();
        
            // Append the new class
            let updatedValue = currentValue ? currentValue + " " + thisClass : thisClass;
        
            return updatedValue;
        });

        $('#layoutClass').attr('value', function(index, currentValue) {
            const unwantedClasses = [
                "cfforms-one-half",
                "cfforms-first",
                "cfforms-one-third",
                "cfforms-one-fourth",
                "cfforms-two-thirds",
                "cfforms-two-fourths"
            ];
            
            // New class to add
            let newClass = 'newClass';
        
            // Remove unwanted classes from the current value
            unwantedClasses.forEach(className => {
                currentValue = currentValue.replace(new RegExp("\\b" + className + "\\b", "gi"), "");
            });
        
            // Clean up extra spaces
            currentValue = currentValue.replace(/\s\s+/g, " ").trim();
        
            // Append the new class
            let updatedValue = currentValue ? currentValue + " " + thisClass : thisClass;
        
            return updatedValue;
        });

        $('#layoutClass').trigger('input');
        $('.toggle-foldable-cont').trigger('click');
    });

    $(document).on('click', '.form-textbox', function () {
        var titleId = $(this).attr('id');
        var titleNumber = titleId.split('-').pop();
        console.log('Clicked on Textbox ' + titleNumber);

        let titleText = $(this).children('input').attr('name') ? $(this).children('input').attr('name') : 'textbox' + titleNumber;
        let placeholderText = $(this).children('input').attr('placeholder') ? $(this).children('input').attr('placeholder') : '';
        let selectedSize = $(this).hasClass('small') ? 'small' : $(this).hasClass('medium') ? 'medium' : $(this).hasClass('large') ? 'large' : '';
        let selectedClass = $(this).attr('class');
        selectedClass = selectedClass.replace('form-textbox', '').trim();
        selectedClass = selectedClass.replace('form-group', '').trim();
        selectedClass = selectedClass.replace(selectedSize, '').trim();
        let hide_label = $(this).children('label').hasClass('hide-label') ? 'checked' : '';
        console.log(hide_label, 'hide_label');
        let selectedLayout = $(this).parent('.cfformselement').parent('.cfformspage').attr('class');
        selectedLayout = selectedLayout.replace('cfformspage', '').trim();
        selectedLayout = selectedLayout.replace(/\bpage-\S+/g, '').trim();
        console.log(selectedLayout, 'selectedLayout');

        let required = $(this).children('input').attr('required') ? 'checked' : '';
        var modalHtml = '';
        // Create modal HTML
        modalHtml = `
            <div class="modal fade" id="textboxModal" tabindex="-1" role="dialog" aria-labelledby="textboxModalLabel" aria-hidden="true" data-type="textbox">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="textboxModalLabel">Edit Textbox ${titleNumber}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="textboxText">Label</label>
                                    <input type="text" class="form-control" id="textboxText" value="${titleText}">
                                </div>
                                <div class="form-group">
                                    <label for="fieldSize">Field Size</label>
                                    <select class="form-control" id="fieldSize">
                                        <option value="small" ${selectedSize === 'small' ? 'selected' : ''}>Small</option>
                                        <option value="medium" ${selectedSize === 'medium' ? 'selected' : ''}>Medium</option>
                                        <option value="large" ${selectedSize === 'large' ? 'selected' : ''}>Large</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="placeholderText">Placeholder Text</label>
                                    <input type="text" class="form-control" id="placeholderText" value="${placeholderText}">
                                </div>
                                <div class="form-group">
                                    <label for="cssClass" class="control-label col-form-label cssClasses">
                                        CSS Classes
                                    </label>
                                    <input type="text" class="form-control" id="cssClass" value="${selectedClass}">
                                </div>
                                <div class="form-group">
                                    <label for="layoutClass" class="control-label col-form-label layoutClasses">
                                        Layout Classes
                                        <a href="#" class="toggle-layout-selector-display toggle-unfoldable-cont"><i class="fa fa-th-large"></i><span>Show Layouts</span></a>
                                        <a href="#" class="toggle-layout-selector-display toggle-foldable-cont" style="display: none;"><i class="fa fa-th-large"></i><span>Hide Layouts</span></a>
                                    </label>
                                    <input type="text" class="form-control" id="layoutClass" value="${selectedLayout}" readonly>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="hideLabel" ${hide_label === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="hideLabel">Hide Label</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="required" ${required === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="required">Required</label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary saveChanges" data-title-id="${titleNumber}">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#textboxModal').remove();

        // Append the new modal to body
        $('body').append(modalHtml);

        // Show the modal
        $('#textboxModal').modal('show');
    });

    $(document).on('click', '.form-radio', function () {
        var titleId = $(this).attr('id');
        var titleNumber = titleId.split('-').pop();
        console.log('Clicked on Radio ' + titleNumber);

        let titleText = $(this).children('label').html() ? $(this).children('label').html() : 'radio' + titleNumber;
        let placeholderText = $(this).children('input').attr('placeholder') ? $(this).children('input').attr('placeholder') : '';
        let selectedSize = $(this).hasClass('small') ? 'small' : $(this).hasClass('medium') ? 'medium' : $(this).hasClass('large') ? 'large' : '';
        let selectedClass = $(this).attr('class');
        selectedClass = selectedClass.replace('form-radio', '').trim();
        selectedClass = selectedClass.replace('form-group', '').trim();
        selectedClass = selectedClass.replace(selectedSize, '').trim();
        let selectedLayout = $(this).parent('.cfformselement').parent('.cfformspage').attr('class');
        selectedLayout = selectedLayout.replace('cfformspage', '').trim();
        selectedLayout = selectedLayout.replace(/\bpage-\S+/g, '').trim();
        let hide_label = $(this).children('label').hasClass('hide-label') ? 'checked' : '';
        let required = $(this).children().children('input').attr('required') ? 'checked' : '';
        let radioLabels = $(this).find('.form-radio-label');
        let radioValues;
        radioLabels.each(function () {
            radioValues = radioValues ? radioValues : '';
            if (radioValues) {
                radioValues = radioValues + ',' + $(this).html();
            } else {
                radioValues = $(this).html();
            }
        });
        console.log(radioValues);
        var modalHtml = '';
        // Create modal HTML
        modalHtml = `
            <div class="modal fade" id="radioModal" tabindex="-1" role="dialog" aria-labelledby="radioModalLabel" aria-hidden="true" data-type="radio">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="radioModalLabel">Edit Radio ${titleNumber}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="radioText">Label</label>
                                    <input type="text" class="form-control" id="radioText" value="${titleText}">
                                </div>
                                <div class="form-group">
                                    <label for="fieldSize">Field Size</label>
                                    <select class="form-control" id="fieldSize">
                                        <option value="small" ${selectedSize === 'small' ? 'selected' : ''}>Small</option>
                                        <option value="medium" ${selectedSize === 'medium' ? 'selected' : ''}>Medium</option>
                                        <option value="large" ${selectedSize === 'large' ? 'selected' : ''}>Large</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="cssClass" class="control-label col-form-label cssClasses">
                                        CSS Classes
                                    </label>
                                    <input type="text" class="form-control" id="cssClass" value="${selectedClass}">
                                </div>
                                <div class="form-group">
                                    <label for="layoutClass" class="control-label col-form-label layoutClasses">
                                        Layout Classes
                                        <a href="#" class="toggle-layout-selector-display toggle-unfoldable-cont"><i class="fa fa-th-large"></i><span>Show Layouts</span></a>
                                        <a href="#" class="toggle-layout-selector-display toggle-foldable-cont" style="display: none;"><i class="fa fa-th-large"></i><span>Hide Layouts</span></a>
                                    </label>
                                    <input type="text" class="form-control" id="layoutClass" value="${selectedLayout}" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="values">Values</label>
                                    <input type="text" class="form-control" id="values" placeholder="Value1, Value2, Value3" value="${radioValues ? radioValues : ''}">
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="hideLabel" ${hide_label === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="hideLabel">Hide Label</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="required" ${required === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="required">Required</label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary saveChanges" data-title-id="${titleNumber}">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#radioModal').remove();

        // Append the new modal to body
        $('body').append(modalHtml);

        // Show the modal
        $('#radioModal').modal('show');
    });

    $(document).on('input', '#cssClass', function () {
        var selectedClass = $(this).val();
        // console.log(selectedClass);
        $(this).attr('value', selectedClass);
    });

    $(document).on('input', '#layoutClass', function () {
        var selectedLayout = $(this).val();
        // console.log(selectedLayout);
        $(this).attr('value', selectedLayout);
    })

    $(document).on('click', '.down-arrow', function () {
        //! move element one step down
        console.log('down arrow clicked');
        $(this).closest('.page-element').insertAfter($(this).closest('.page-element').next());
    });
    //! move element one step up
    $(document).on('click', '.up-arrow', function () {
        console.log('up arrow clicked');
        $(this).closest('.page-element').insertBefore($(this).closest('.page-element').prev());
    });
    $(document).on('click', '.saveChanges', function () {
        console.log('Save changes clicked');
        var modal = $(this).closest('.modal');
        console.log(modal, 'modal');
        var type = modal.data('type');
        console.log(type, 'type');
        var titleId = $(this).data('title-id');
        var textboxText = $('#textboxText').val();
        var checkboxText = $('#checkboxText').val();
        var dropdownText = $('#dropdownText').val();
        var fieldSize = $('#fieldSize').val();
        // var fieldSize = $('#fieldSize').attr('value');
        var placeholderText = $('#placeholderText').val();
        let layoutClass = $('#layoutClass').attr('value');
        let cssClass = $('#cssClass').attr('value');
        var hideLabel = $('#hideLabel').is(':checked');
        var radioText = $('#radioText').val();
        var values = $('#values').val();
        var required = $('#required').is(':checked');
        var titleText = $('#' + type + 'Text').val();

        // Update the title element with new values
        var element = $('#form-' + type + '-' + titleId);
        console.log(element, 'element');
        if (titleText) {
            console.log(titleText, 'titleText');
            if (type === 'title') {
                element.text(titleText);
            } else {
                element.children('label').text(titleText);
                element.find('label').text(titleText);
                element.find('input').attr('name', titleText);
            }
        }
        if (fieldSize) {
            console.log(fieldSize, 'fieldSize');
            element.removeClass('small medium large').addClass(fieldSize);
        }
        if (placeholderText) {
            element.find('input').attr('placeholder', placeholderText);
        }
        if (cssClass) {
            // console.log(cssClass, 'cssClass');
            const exemptClasses = [
                'form-group',
                'form-radio',
                'form-title',
                'form-textbox',
                'small',
                'medium',
                'large',
                'form-checkbox',
                'form-dropdown'
            ];

            element.attr('class', function (i, c) {
                // Split existing classes into an array
                const existingClasses = c ? c.split(/\s+/) : [];

                // Filter out non-exempt classes
                const retainedClasses = existingClasses.filter(className =>
                    exemptClasses.includes(className)
                );

                // Add the new cssClass while keeping exempted classes
                return [...retainedClasses, cssClass].join(' ');
            });
            /* element.attr('class', function(i, c) {
                return c.replace(/(^|\s)custom-\S+/g, '') + ' ' + cssClass;
            }); */
        }
        
        if (layoutClass) {
            console.log(layoutClass, 'layoutClass');
            const exemptClasses = [
                'page-element',
                'cfformspage'
            ];
            const cfformsPrefixRegex = /^cfforms-/;  // Regex to match any class starting with 'cfforms-'
            
            console.log(element.parent().parent('.cfformspage'), 'test');
            element.parent().parent('.cfformspage').attr('class', function (i, c) {
                // Split existing classes into an array
                const existingClasses = c ? c.split(/\s+/) : [];
        
                // Filter out classes that start with 'cfforms-' and replace them with layoutClass
                const updatedClasses = existingClasses.filter(className => {
                    // Keep classes that are exempt or do not start with 'cfforms-'
                    return exemptClasses.includes(className) || !cfformsPrefixRegex.test(className);
                });
        
                // Add the new layoutClass while keeping exempted classes
                updatedClasses.push(layoutClass);
        
                // Return the updated class list as a string
                return updatedClasses.join(' ');
            });        
        }
        
        
        if (radioText) {
            element.find('label').text(radioText);
        }
        if (hideLabel) {
            element.find('label').addClass('hide-label');
        } else {
            element.find('label').removeClass('hide-label');
        }

        if (required) {
            element.find('input').attr('required', 'required');
        } else {
            element.find('input').removeAttr('required');
        }
        // element.find('input').attr('required', required);
        if (values && type === 'radio') {
            element.find('.form-radio').remove();
            var innerRadioElement = '<div class="form-radio">';
            console.log(values, 'values radio');
            values.split(',').forEach(function (value, index) {
                var trimmedValue = value.trim();
                innerRadioElement += `<div class="form-radio-item">`;
                innerRadioElement += `<input class="form-radio-input form-radio" type="radio" name="${radioText}" id="${radioText}-${trimmedValue}" value="${trimmedValue}"${required && index === 0 ? ' required' : ''}>`;
                innerRadioElement += `<label class="form-radio-label" for="${radioText}-${trimmedValue}">${trimmedValue}</label>`;
                innerRadioElement += '</div>';
            });
            innerRadioElement += '</div>';
            element.append(innerRadioElement);
        } else if (values && type === 'checkbox') {
            element.find('.form-checkbox').remove();
            var innerCheckboxElement = '<div class="form-checkbox cf-form-checkbox">';
            values.split(',').forEach(function (value, index) {
                var trimmedValue = value.trim();
                innerCheckboxElement += `<div class="form-checkbox-item">`;
                innerCheckboxElement += `<input class="form-checkbox-input form-check" type="checkbox" name="${checkboxText}" id="${checkboxText}-${trimmedValue}" value="${trimmedValue}"${required && index === 0 ? ' required' : ''}>`;
                innerCheckboxElement += `<label class="form-checkbox-label" for="${checkboxText}-${trimmedValue}">${trimmedValue}</label>`;
                innerCheckboxElement += '</div>';
            });
            innerCheckboxElement += '</div>';
            element.append(innerCheckboxElement);
        } else if (values && type === 'dropdown') {
            element.find('.form-dropdown').remove();
            var innerDropdownElement = '<div class="form-dropdown">';
            innerDropdownElement += `<select class="form-dropdown-select form-select" name="${dropdownText}" id="${dropdownText}" ${required ? 'required' : ''}>`;
            innerDropdownElement += `<option value="">Please select ${dropdownText}</option>`;
            values.split(',').forEach(function (value, index) {
                var trimmedValue = value.trim();
                innerDropdownElement += `<option value="${trimmedValue}">${trimmedValue}</option>`;
            });
            innerDropdownElement += '</select></div>';
            element.append(innerDropdownElement);
        }
        //! Close the modal
        modal.modal('hide');
        //! set timeout to remove the modal after 500ms
        setTimeout(function () {
            modal.remove();
        }, 500);
    });

    $(document).on('click', '.form-checkbox', function () {
        var titleId = $(this).attr('id');
        var titleNumber = titleId.split('-').pop();
        console.log('Clicked on Checkbox ' + titleNumber);

        let titleText = $(this).children('label').html() ? $(this).children('label').html() : 'checkbox' + titleNumber;
        let selectedSize = $(this).hasClass('small') ? 'small' : $(this).hasClass('medium') ? 'medium' : $(this).hasClass('large') ? 'large' : '';
        let selectedClass = $(this).attr('class');
        selectedClass = selectedClass.replace('form-checkbox', '').trim();
        selectedClass = selectedClass.replace('form-group', '').trim();
        selectedClass = selectedClass.replace(selectedSize, '').trim();
        let selectedLayout = $(this).parent('.cfformselement').parent('.cfformspage').attr('class');
        selectedLayout = selectedLayout.replace('cfformspage', '').trim();
        selectedLayout = selectedLayout.replace(/\bpage-\S+/g, '').trim();
        let hide_label = $(this).children('label').hasClass('hide-label') ? 'checked' : '';
        let required = $(this).children().children('input').attr('required') ? 'checked' : '';
        let checkboxLabels = $(this).find('.form-checkbox-label');
        let checkboxValues;
        checkboxLabels.each(function () {
            checkboxValues = checkboxValues ? checkboxValues : '';
            if (checkboxValues) {
                checkboxValues = checkboxValues + ',' + $(this).html();
            } else {
                checkboxValues = $(this).html();
            }
        });
        console.log(checkboxValues);

        var modalHtml = '';
        //! Create modal HTML
        modalHtml = `
            <div class="modal fade" id="checkboxModal" tabindex="-1" role="dialog" aria-labelledby="checkboxModalLabel" aria-hidden="true" data-type="checkbox">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="checkboxModalLabel">Edit Checkbox ${titleNumber}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="checkboxText">Label</label>
                                    <input type="text" class="form-control" id="checkboxText" value="${titleText}">
                                </div>
                                <div class="form-group">
                                    <label for="fieldSize">Field Size</label>
                                    <select class="form-control" id="fieldSize">
                                        <option value="small" ${selectedSize === 'small' ? 'selected' : ''}>Small</option>
                                        <option value="medium" ${selectedSize === 'medium' ? 'selected' : ''}>Medium</option>
                                        <option value="large" ${selectedSize === 'large' ? 'selected' : ''}>Large</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="cssClass" class="control-label col-form-label cssClasses">
                                        CSS Classes
                                    </label>
                                    <input type="text" class="form-control" id="cssClass" value="${selectedClass}">
                                </div>
                                <div class="form-group">
                                    <label for="layoutClass" class="control-label col-form-label layoutClasses">
                                        Layout Classes
                                        <a href="#" class="toggle-layout-selector-display toggle-unfoldable-cont"><i class="fa fa-th-large"></i><span>Show Layouts</span></a>
                                        <a href="#" class="toggle-layout-selector-display toggle-foldable-cont" style="display: none;"><i class="fa fa-th-large"></i><span>Hide Layouts</span></a>
                                    </label>
                                    <input type="text" class="form-control" id="layoutClass" value="${selectedLayout}" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="values">Values</label>
                                    <input type="text" class="form-control" id="values" placeholder="Value1, Value2, Value3" value="${checkboxValues ? checkboxValues : ''}">
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="hideLabel" ${hide_label === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="hideLabel">Hide Label</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="required" ${required === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="required">Required</label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary saveChanges" data-title-id="${titleNumber}">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#checkboxModal').remove();

        // Append the new modal to body
        $('body').append(modalHtml);

        // Show the modal
        $('#checkboxModal').modal('show');
    });

    $(document).on('click', '.form-dropdown', function () {
        var titleId = $(this).attr('id');
        var placeholderText = $(this).children().children('select').attr('placeholder') ? $(this).children().children('select').attr('placeholder') : '';
        var titleNumber = titleId.split('-').pop();
        var labelText = $(this).children().children('select').attr('name') ? $(this).children().children('select').attr('name') : 'dropdown ' + titleNumber;
        console.log('Clicked on Dropdown ' + titleNumber);

        let selectedSize = $(this).hasClass('small') ? 'small' : $(this).hasClass('medium') ? 'medium' : $(this).hasClass('large') ? 'large' : '';
        let selectedClass = $(this).attr('class');
        selectedClass = selectedClass.replace('form-dropdown', '').trim();
        selectedClass = selectedClass.replace('form-group', '').trim();
        selectedClass = selectedClass.replace(selectedSize, '').trim();
        let selectedLayout = $(this).parent('.cfformselement').parent('.cfformspage').attr('class');
        selectedLayout = selectedLayout.replace('cfformspage', '').trim();
        selectedLayout = selectedLayout.replace(/\bpage-\S+/g, '').trim();
        let hide_label = $(this).children('label').hasClass('hide-label') ? 'checked' : '';
        let required = $(this).children().children('input').attr('required') ? 'checked' : '';
        let dropdownLabels = $(this).find('.form-dropdown-select').children('option');
        let dropdownValues;
        dropdownLabels.each(function (index, element) {
            if (index === 0) return;
            dropdownValues = dropdownValues ? dropdownValues : '';
            if (dropdownValues) {
                dropdownValues = dropdownValues + ',' + $(this).html();
            } else {
                dropdownValues = $(this).html();
            }
        });
        console.log(dropdownValues);

        var modalHtml = '';
        // Create modal HTML
        modalHtml = `
            <div class="modal fade" id="dropdownModal" tabindex="-1" role="dialog" aria-labelledby="dropdownModalLabel" aria-hidden="true" data-type="dropdown">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="dropdownModalLabel">Edit Dropdown ${titleNumber}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="dropdownText">Label</label>
                                    <input type="text" class="form-control" id="dropdownText" value="${labelText}">
                                </div>
                                <div class="form-group">
                                    <label for="fieldSize">Field Size</label>
                                    <select class="form-control" id="fieldSize">
                                        <option value="small" ${selectedSize === 'small' ? 'selected' : ''}>Small</option>
                                        <option value="medium" ${selectedSize === 'medium' ? 'selected' : ''}>Medium</option>
                                        <option value="large" ${selectedSize === 'large' ? 'selected' : ''}>Large</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="cssClass" class="control-label col-form-label cssClasses">
                                        CSS Classes
                                    </label>
                                    <input type="text" class="form-control" id="cssClass" value="${selectedClass}">
                                </div>
                                <div class="form-group">
                                    <label for="layoutClass" class="control-label col-form-label layoutClasses">
                                        Layout Classes
                                        <a href="#" class="toggle-layout-selector-display toggle-unfoldable-cont"><i class="fa fa-th-large"></i><span>Show Layouts</span></a>
                                        <a href="#" class="toggle-layout-selector-display toggle-foldable-cont" style="display: none;"><i class="fa fa-th-large"></i><span>Hide Layouts</span></a>
                                    </label>
                                    <input type="text" class="form-control" id="layoutClass" value="${selectedLayout}" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="values">Values</label>
                                    <input type="text" class="form-control" id="values" placeholder="Value1, Value2, Value3" value="${dropdownValues ? dropdownValues : ''}">
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="hideLabel" ${hide_label === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="hideLabel">Hide Label</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="required" ${required === 'checked' ? 'checked' : ''}>
                                        <label class="custom-control-label" for="required">Required</label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary saveChanges" data-title-id="${titleNumber}">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#dropdownModal').remove();

        // Append the new modal to body
        $('body').append(modalHtml);

        // Show the modal
        $('#dropdownModal').modal('show');
    });

    $(document).on('click', '#cf-save-form', function () {
        var data = {};
        var errors = [];

        // Get all form data from the form builder
        $('#formsettings').serializeArray().forEach(function(field) {
            console.log(field, 'field');
            // Check if the field is required and if it's empty
            if (jQuery('[name="' + field.name + '"]').attr('required') && !field.value) {
                errors.push(field.name + ' is required');
                jQuery('[name="' + field.name + '"]').addClass('is-invalid');
            } else {
                data[field.name] = field.value;
                jQuery('[name="' + field.name + '"]').removeClass('is-invalid');
            }
        });
        console.log(errors, 'errors');

        // If there are errors, display them
        if (errors.length > 0) {
            alert(errors.join("\n"));
            $('#formsettingtab').trigger('click');
            return false;
        } else {
            // Proceed with form submission or further processing
            console.log('Form data:', data);
        }

        //! get form data from form builder
        var formData = $('#form-builder-drop-area').html();
        console.log(formData);
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'cf_save_form_data', form_data: formData, settings: data },
            success: function (response) {
                console.log(response);
                window.location.href = 'admin.php?page=custom-form-builder-forms';
            },
            error: function (response) {
                console.log(response);
            }
        });
    });

    $(document).on('click', '#cf-save-edited-form', function () {
        var formData = $('#form-builder-drop-area').html().trim();
        var formId = $(this).data('form-id');
        console.log(formData);
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'cf_save_edited_form_data', form_data: formData, form_id: formId },
            success: function (response) {
                console.log(response);
                window.location.href = 'admin.php?page=custom-form-builder-forms';
            },
            error: function (response) {
                console.log(response);
            }
        });
    });

    $(document).on('click', '#cf-publish-form', function () {
        var formId = $(this).data('form-id');
        console.log(formId);
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'cf_publish_form', form_id: formId },
            success: function (response) {
                console.log(response);
                window.location.reload();
            },
            error: function (response) {
                console.log(response);
            }
        });
    });

    $(document).on('click', '.cf-delete-form', function () {
        var formId = $(this).data('form-id');
        console.log(formId);
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'cf_delete_form', form_id: formId },
            success: function (response) {
                console.log(response);
                window.location.reload();
            },
            error: function (response) {
                console.log(response);
            }
        });
    });

    /* var pageelement = $('.page-element');
    pageelement.each(function() {
        var element = $(this);

        //! add a bin for deleting the element
        var bin = $('<div class="bin"><i class="fa fa-trash"></i></div>');
        bin.on('click', function() {
            element.remove();
        });
        element.append(bin);
    }); */

    $(document).on('click', '.bin', function () {
        $(this).parent().remove();
        // $('#cf-save-edited-form').trigger('click');
    });

    $(document).on('click', '.upclick', function () {
        var element = $(this).parent().parent('.page-element');
        element.insertBefore(element.prev());
        // $('#cf-save-edited-form').trigger('click');
    });

    $(document).on('click', '.downclick', function () {
        var element = $(this).parent().parent('.page-element');
        element.insertAfter(element.next());
        // $('#cf-save-edited-form').trigger('click');
    });

    $(document).on('click', '.edit-button', function () {
        console.log('Edit button clicked');
        $(this).parent().children('.dropped-element').children('.form-group').trigger('click');
    });

    $(document).on('click', '.cfsettings', function () {

    });
});