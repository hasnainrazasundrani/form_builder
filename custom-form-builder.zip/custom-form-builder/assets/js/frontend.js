document.addEventListener("DOMContentLoaded", function () {
    //! Select all pages and form
    const pages = document.querySelectorAll(".page-element");
    const lastPage = pages[pages.length - 1];
    //! Retrieve the class attribute of the last page element
    const lastPageClasses = lastPage.className;
    //! get number from lastPageClasses
    var lastPageNumber = lastPageClasses.match(/\d+/)[0];
    // console.log(lastPageNumber);
    const form = document.querySelector(".custom-form");
    const submitButton = form.querySelector("input[type='submit']");
    let submitButtonParent = submitButton.parentNode;
    submitButtonParent.style.display = 'none';
    
    let currentPageIndex = 1;
    
    // Function to show the current page
    function showPage(index) {
        // console.log(index, 'showPage');
        currentPageIndex = index;
        const prevPageIndex = index - 1;
        const showAllEdit = jQuery('div.edit_page_division');
        if(showAllEdit){
            showAllEdit.show();
        }
        const currentPageEdit = jQuery('div.page_'+currentPageIndex+'_edit');
        if(currentPageEdit){
            currentPageEdit.hide();
        }
        pages.forEach((page, i) => {
            if(page.classList.contains('page-'+currentPageIndex)){
                // console.log(page, 'page');
                if(!page.classList.contains('show-page-title')){
                    page.style.display = 'block';
                }else{
                    page.style.display = 'flex';
                    page.style.justifyContent = 'space-between';
                }
            }else{
                if(!page.classList.contains('show-page-title')){
                    page.style.display = 'none';
                }else{
                    page.style.display = 'flex';
                    page.style.justifyContent = 'space-between';
                }
            }
        });

        if(currentPageIndex == lastPageNumber){
            submitButton.style.display = 'block';
            submitButtonParent.style.display = 'flex';
        }else{
            submitButton.style.display = 'none';
            submitButtonParent.style.display = 'none';
        }
    }

    //! Function to navigate to the next page
    function nextPage() {
        if (currentPageIndex < pages.length - 1) {
            currentPageIndex++;
            showPage(currentPageIndex);
        }
    }

    //! Function to navigate to the previous page
    function prevPage() {
        const currentPageEdit = jQuery('div.page_'+currentPageIndex+'_edit');
        if(currentPageEdit){
            currentPageEdit.show();
        }
        if (currentPageIndex > 0) {
            currentPageIndex--;
            const currentPageEdit = jQuery('div.page_'+currentPageIndex+'_edit');
            if(currentPageEdit){
                currentPageEdit.hide();
            }
            showPage(currentPageIndex);
        }
    }

    //! Add a "Next" button at the page breaks
    document.querySelectorAll(".form-page-break").forEach((breakElement, index) => {
        const nextButton = document.createElement("button");
        nextButton.type = "button";
        nextButton.className = "btn btn-primary next-button";
        nextButton.setAttribute('data-page', index + 1);
        nextButton.textContent = "Next";
        nextButton.addEventListener("click", nextPage);
        const hrElement = document.createElement("hr");
        breakElement.innerHTML = "";
        breakElement.appendChild(nextButton);
        breakElement.appendChild(hrElement);
        

        //! Add a "Previous" button if it's not the first page
        if (index > 0) {
            const prevButton = document.createElement("button");
            prevButton.type = "button";
            prevButton.className = "btn btn-secondary prev-button";
            prevButton.textContent = "Previous";
            prevButton.addEventListener("click", prevPage);
            breakElement.prepend(prevButton); // Add at the top of the page
        }

        //! title of next page and edit label
        const breakParentElement = breakElement.parentElement.parentElement;
        const nextElement = breakParentElement.nextElementSibling;
        const nextFormTitle = nextElement.querySelector('.form-title');
        // console.log(nextFormTitle, 'nextFormTitle');
        if(nextFormTitle){
            // console.log(nextElement, 'nextElement');
            nextElement.classList.add('show-page-title');
            const editLabel = document.createElement('label');
            editLabel.className = 'edit-page';
            editLabel.textContent = 'Edit';
            const editDiv = document.createElement('div');
            editDiv.className = 'edit_page_division page_'+(index + 2)+'_edit';
            editDiv.appendChild(editLabel);
            nextElement.appendChild(editDiv);
        }
    });

    // console.log(currentPageIndex, 'currentPageIndex1');
    if(currentPageIndex >= 1){
        //! title of the first page
        const firstPage = document.querySelector('.page-element.page-1');
        firstPage.classList.add('show-page-title');
        const editLabel = document.createElement('label');
        editLabel.className = 'edit-page';
        editLabel.textContent = 'Edit';
        const editDiv = document.createElement('div');
        editDiv.className = 'edit_page_division page_1_edit';
        editDiv.appendChild(editLabel);
        firstPage.appendChild(editDiv);
        
        //! Add a "Previous" button at the last page
        const lastPageButton = document.createElement("button");
        lastPageButton.type = "button";
        lastPageButton.className = "btn btn-secondary prev-button";
        lastPageButton.textContent = "Previous";
        lastPageButton.addEventListener("click", prevPage);
        submitButtonParent.insertBefore(lastPageButton, submitButton);
    }


    //! Initialize the form: show the first page
    showPage(currentPageIndex);

    jQuery(document).ready(function($) {
        // console.log('Hello from frontend');
        const currentPageEdit = jQuery('div.page_'+currentPageIndex+'_edit');
        if(currentPageEdit){
            currentPageEdit.hide();
        }
    });

    jQuery('.edit-page').on('click', function() {
        var page = jQuery(this).parent();
        const currentPageClasses = page.attr('class');
        //! get number from lastPageClasses
        var currentPageNumber = currentPageClasses.match(/\d+/)[0];
        showPage(currentPageNumber);
    });

    jQuery('#formSubmit').on('click', function(event) {
        event.preventDefault();
    
        // Create a new FormData object
        var formData = {};
        var data = {};
        // Get all form data from the form builder
        jQuery('.custom-form').serializeArray().forEach(function(field) {
            // formData.append(field.name, field.value);
            formData[field.name] = field.value;
        });
    
        // Add the form ID
        var formId = jQuery('.custom-form').data('id');
        data['formdata'] = formData;
        data['action'] = 'cf_send_form';
        data['form_id'] = formId;
    
        //! Send the AJAX request
        jQuery.ajax({
            url: cf_ajax.ajaxurl,
            type: 'POST',
            data: data,
            success: function(response) {
                jQuery('#formSubmit').parent().html(response.data.message);
                
            },
            error: function(error) {
                // console.error('Error:', error);
            }
        });
    });
    
});