<?php
/*
Plugin Name: Custom Form Builder
Description: A WordPress plugin for creating forms using drag-and-drop functionality.
Version: 1.0.0
Author: Hasnainraza Sundrani
*/

// Register scripts and styles
function cf_enqueue_assets() {
    wp_enqueue_style('cf-styles', plugin_dir_url(__FILE__) . 'assets/css/styles.css');
    wp_enqueue_script('cf-scripts', plugin_dir_url(__FILE__) . 'assets/js/scripts.js', array('jquery', 'jquery-ui-sortable'), '1.0', true);
    //! include the bootstrap library
    wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), '4.5.2', true);
}
add_action('admin_enqueue_scripts', 'cf_enqueue_assets');

function cf_front_enqueue_scripts() {
    wp_enqueue_style('cf_stylesheet', plugin_dir_url(__FILE__) . 'assets/css/frontend.css');
    wp_enqueue_style( 'cf_stylesheet' );
    wp_enqueue_script('cf-scriptsheet', plugin_dir_url(__FILE__) . 'assets/js/frontend.js', array('jquery', 'jquery-ui-sortable'), '1.0', true);
    //! ajaxurl to script
    wp_localize_script( 'cf-scriptsheet', 'cf_ajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
    wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), '4.5.2', true);
}
add_action( 'wp_enqueue_scripts', 'cf_front_enqueue_scripts' );

function custom_form_builder_menu() {
    // Add a top-level menu page
    add_menu_page(
        'Form Builder', // Page title
        'Form Builder', // Menu title
        'manage_options', // Capability (who can access)
        'custom-form-builder', // Menu slug
        'custom_form_builder_forms_page', // Callback function to display content
        'dashicons-editor-table', // Icon (optional)
        6 // Position (optional)
    );

    //! add menu for listing all forms
    add_submenu_page(
        'custom-form-builder',
        'Forms',
        'Forms',
        'manage_options',
        'custom-form-builder-forms',
        'custom_form_builder_forms_page',
        'dashicons-editor-table',
        1
    );

    //! add menu for adding new form
    add_submenu_page(
        'custom-form-builder',
        'Add New Form',
        'Add New Form',
        'manage_options',
        'custom-form-builder-add-new',
        'custom_form_builder_page',
        'dashicons-plus',
        2
    );

    //! add menu for editing form not showing in sidebar
    add_submenu_page(
        null,
        'Edit Form',
        'Edit Form',
        'manage_options',
        'custom-form-builder-edit-form',
        'custom_form_builder_edit_form_page',
    );
    
    //! add menu for editing form not showing in sidebar
    add_submenu_page(
        null,
        'Settings',
        'Settings',
        'manage_options',
        'custom-form-builder-settings',
        'custom_form_builder_settings_page',
    );
}
add_action('admin_menu', 'custom_form_builder_menu');

//! create forms page
function custom_form_builder_forms_page() {
    include(plugin_dir_path(__FILE__) . 'templates/forms.php');
}

//! Create a shortcode to display the form builder
function custom_form_builder_page() {
    include(plugin_dir_path(__FILE__) . 'templates/form-builder.php');
}

//! edit form page
function custom_form_builder_edit_form_page() {
    include(plugin_dir_path(__FILE__) . 'templates/edit-form.php');
}

//! settings page
function custom_form_builder_settings_page() {
    include(plugin_dir_path(__FILE__) . 'templates/form-settings.php');
}


function cf_save_form_data() {
    global $wpdb;
    if (isset($_POST['form_data'])) {
        $form_data = $_POST['form_data'];
        
        // Insert the form data first
        $wpdb->insert(
            "{$wpdb->prefix}cf_form_data",
            array(
                'form_data' => $form_data,
                'status' => 'published'
            )
        );
        
        // Get the inserted ID
        $form_id = $wpdb->insert_id;
        
        // Generate the shortcode using the actual form ID
        $shortcode = 'cf_' . $form_id . '_' . time();
        
        // Update the record with the generated shortcode
        $wpdb->update(
            "{$wpdb->prefix}cf_form_data",
            array('shortcode' => $shortcode, 'form_title' => $_POST['settings']['form_title'], 'submit_button_text' => $_POST['settings']['submit_button_text'], 'success_message' => $_POST['settings']['success_message'], 'error_message' => $_POST['settings']['error_message'], 'send_to_email' => $_POST['settings']['send_to_email'], 'email_subject' => $_POST['settings']['email_subject'], 'email_body' => $_POST['settings']['email_body']),
            array('id' => $form_id)
        );

        add_shortcode($shortcode, 'cf_show_form');
        
        wp_send_json_success(array('shortcode' => $shortcode));
    }
    wp_send_json_error();
}
add_action('wp_ajax_cf_save_form_data', 'cf_save_form_data');

function register_my_custom_form_db_shortcode() {
    //! add shortcode for testing
    add_shortcode('cf_form', 'cf_show_form');
}
add_action('init', 'register_my_custom_form_db_shortcode');

//! create tables on activation
function cf_create_tables() {
    global $wpdb;
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cf_form_data (id INT AUTO_INCREMENT PRIMARY KEY, form_data TEXT, shortcode TEXT, status TEXT, form_title TEXT, success_message TEXT, error_message TEXT, send_to_email TEXT, email_subject TEXT, email_body TEXT, submit_button_text TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cf_form_submissions (id INT AUTO_INCREMENT PRIMARY KEY, form_data TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
}
register_activation_hook(__FILE__, 'cf_create_tables');

//! show form using shortcode
function cf_show_form($atts, $content = null, $shortcode_tag = '') {
    global $wpdb;
    $shortcode = $atts['id'];
    $data = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}cf_form_data WHERE shortcode = '$shortcode' AND status = 'published'");
    // echo '<pre>'; print_r($data->form_data); echo '</pre>'; die('hasnain');
    $form_data = stripslashes($data->form_data);
    
    // Generate a unique form ID
    $form_id = 'cf_form_' . $shortcode;
    
    // Wrap the form content in a <form> tag with ID and add a submit button
    $output = '<form id="' . esc_attr($form_id) . '" class="custom-form cfforms" method="post" data-id="' . esc_attr($data->id) . '">';
    $output .= do_shortcode($form_data);
    $output .= '<div class="form-group form-actions wpforms-submit-container">';
    $output .= '<div class="form-buttons">';
    $output .= '<input type="submit" id="formSubmit" value="'. $data->submit_button_text .'" class="btn btn-primary">';
    $output .= '</div>';
    $output .= '</div>';
    $output .= '</form>';
    
    return $output;
}
add_shortcode('cf_form', 'cf_show_form');

//! save edited form data
function cf_save_edited_form_data() {
    global $wpdb;
    $form_data = $_POST['form_data'];
    $form_id = $_POST['form_id'];
    $wpdb->update("{$wpdb->prefix}cf_form_data", array('form_data' => $form_data), array('id' => $form_id));
    wp_send_json_success();
}
add_action('wp_ajax_cf_save_edited_form_data', 'cf_save_edited_form_data');

//! publish form
function cf_publish_form() {
    global $wpdb;
    $form_id = $_POST['form_id'];
    //! check if form is already published
    $form_status = $wpdb->get_var("SELECT status FROM {$wpdb->prefix}cf_form_data WHERE id = $form_id");
    if ($form_status == 'published') {
        //! unpublish the form
        $wpdb->update("{$wpdb->prefix}cf_form_data", array('status' => 'draft'), array('id' => $form_id));
    } else {
        //! publish the form
        $wpdb->update("{$wpdb->prefix}cf_form_data", array('status' => 'published'), array('id' => $form_id));
    }
    wp_send_json_success();
}
add_action('wp_ajax_cf_publish_form', 'cf_publish_form');

//! delete form
function cf_delete_form() {
    global $wpdb;
    $form_id = $_POST['form_id'];
    $wpdb->delete("{$wpdb->prefix}cf_form_data", array('id' => $form_id));
    wp_send_json_success();
}
add_action('wp_ajax_cf_delete_form', 'cf_delete_form');

add_action('wp_ajax_cf_send_form', 'cf_send_form');
add_action('wp_ajax_nopriv_cf_send_form', 'cf_send_form');

function cf_send_form() {
    global $wpdb;
    $form_id = $_POST['form_id'];
    $formdata = $_POST['formdata'];

    $formAttrs = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}cf_form_data WHERE id = $form_id");
    $success_message = $formAttrs->success_message;
    $error_message = $formAttrs->error_message;
    $send_to_email = $formAttrs->send_to_email;
    $email_subject = $formAttrs->email_subject;
    $email_body = $formAttrs->email_body;

    //! send mail
    $to = $send_to_email;
    $subject = $email_subject;
    $message = $email_body;
    foreach ($formdata as $key => $value) {
        $message .= "<p><strong>$key:</strong> $value</p>";
    }
    $headers = 'From: ' . get_bloginfo('name') . ' <' . get_bloginfo('admin_email') . '>' . "\r\n" .
        'Reply-To: ' . get_bloginfo('admin_email') . "\r\n" .
        'Content-Type: text/plain; charset=UTF-8' . "\r\n";
    $success = wp_mail($to, $subject, $message, $headers);
    
    if ($success) {
        wp_send_json_success(array('message' => $success_message));
    } else {
        wp_send_json_error(array('message' => $error_message));
    }
    // $wpdb->insert("{$wpdb->prefix}cf_form_submissions", array('form_data' => $form_data));
    // wp_send_json_success();
}