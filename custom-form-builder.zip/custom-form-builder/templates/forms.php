<?php
global $wpdb;
$forms = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cf_form_data");
?>

<div class="wrap">
    <a href="<?php echo admin_url('admin.php?page=custom-form-builder-add-new'); ?>" class="button button-primary">Add New Form</a>
    <h1>Forms</h1>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Shortcode</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($forms as $form) : ?>
                <tr>
                    <td><?php echo $form->id; ?></td>
                    <td><?php echo $form->form_title ? $form->form_title : 'Untitled'; ?></td>
                    <td><?php echo '[cf_form id="' . $form->shortcode . '"]'; ?></td>
                    <td><?php echo $form->status; ?></td>
                    <td>
                        <a href="<?php echo admin_url('admin.php?page=custom-form-builder-edit-form&id=' . $form->id); ?>"><img height="20px" width="20px" src="<?php echo plugin_dir_url( __DIR__).'assets/icons/edit.png'; ?>"></a>
                        <a href="#" class="cf-delete-form" data-form-id="<?php echo $form->id; ?>"><img height="20px" width="20px" src="<?php echo plugin_dir_url( __DIR__).'assets/icons/bin.png'; ?>"></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
