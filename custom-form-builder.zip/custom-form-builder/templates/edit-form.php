<?php
global $wpdb;
$form = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}cf_form_data WHERE id = " . $_GET['id']);
?>
<div class="wrap d-flex justify-content-between align-items-center">
    <div>
        <h1>Edit Form</h1>
        <h4>Status: <?php echo $form->status; ?></h4>
        <button id="cf-publish-form" data-form-id="<?php echo $form->id; ?>" class="button button-primary"><?php echo $form->status == 'draft' ? 'Publish' : 'Unpublish'; ?></button>
    </div>
    <div>
        <a href="<?php echo admin_url('admin.php?page=custom-form-builder-forms'); ?>" class="button button-primary">Back to Forms</a>
        <a href="<?php echo admin_url('admin.php?page=custom-form-builder-settings&form_id=' . $form->id . ''); ?>" class="button button-secondary">Settings</a>
    </div>
</div>

<div class="cf-form-builder-wrapper row">
    <div class="form-elements col-md-3">
        <h3>Form Elements</h3>
        <ul class="form-elements-list">
            <li class="form-element" draggable="true" data-type="textbox">
                Textbox
            </li>
            <li class="form-element" draggable="true" data-type="radio">
                Radio Button
            </li>
            <li class="form-element" draggable="true" data-type="checkbox">
                Checkbox
            </li>
            <li class="form-element" draggable="true" data-type="title">
                Title
            </li>
            <li class="form-element" draggable="true" data-type="dropdown">
                Dropdown
            </li>
            <li class="form-element" draggable="true" data-type="section-divider">
                Section Divider
            </li>
            <li class="form-element" draggable="true" data-type="page-break">
                Page Break
            </li>
        </ul>
    </div>
    <div class="form-builder-area col-md-9">
        <h3>Form Builder</h3>
        <div class="form-builder" id="form-builder-drop-area" style="height: 500px; overflow-y: auto;padding-bottom:100px">
            <?php echo wp_unslash(html_entity_decode($form->form_data)); ?>
        </div>
    </div>
</div>

<button id="cf-save-edited-form" data-form-id="<?php echo $form->id; ?>">Save Form</button>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var pageelement = jQuery('.page-element');
    pageelement.each(function() {
        var element = jQuery(this);

        //! add a bin for deleting the element
        // var bin = jQuery('<div class="bin"><i class="fa fa-trash"></i></div>');
        /* bin.on('click', function() {
            element.remove();
        }); */
        // element.append(bin);

        /* var upDownArrow = document.createElement('div');
        upDownArrow.className = 'up-down-arrow';
        upDownArrow.innerHTML = '<i class="fa fa-arrow-up"></i><i class="fa fa-arrow-down"></i>';
        element.append(upDownArrow); */
    });

    const formElements = document.querySelectorAll('.form-element');
    const dropArea = document.getElementById('form-builder-drop-area');
    var formBuilder = document.querySelector('.form-builder');

    formElements.forEach(element => {
        element.addEventListener('dragstart', dragStart);
    });

    dropArea.addEventListener('dragover', dragOver);
    dropArea.addEventListener('drop', drop);

    function dragStart(e) {
        console.log('drag start');
        e.dataTransfer.setData('text/plain', e.target.getAttribute('data-type'));
    }

    function dragOver(e) {
        e.preventDefault();
    }

    function drop(e) {
        console.log('drop');
        e.preventDefault();
        const elementType = e.dataTransfer.getData('text');
        console.log('drop', elementType);
        var pageBreakCount = formBuilder.querySelectorAll('.form-page-break').length;
        console.log(pageBreakCount, 'pageBreakCount');
        const newElement = createFormElement(elementType);
        var page = document.createElement('div');
        page.className = 'page-element cfformspage page-' + (pageBreakCount + 1);
        page.attributes = 'draggable=true';
        // page.attributes = 'id="page' + (pageBreakCount + 1) + '"';
        /* if(elementType == "page-break") {
            var page = document.createElement('div');
            page.className = 'page-element page-' + (pageBreakCount + 1) + '"';
            page.attributes = 'id="page' + (pageBreakCount + 1) + '"';
        }else{
            // var page = document.getElementsByClassName('page-' + (pageBreakCount + 1));
            var page = document.getElementsByClassName('page-' + (pageBreakCount))[0];
            console.log(page, 'page');
        } */
        page.appendChild(newElement);
        //! edit button
        const editButton = document.createElement('div');
        editButton.className = 'edit-button hideinfront';
        editButton.innerHTML = '<img height="20px" width="20px" src="<?php echo plugin_dir_url( __DIR__).'assets/icons/edit.png'; ?>">';
        page.appendChild(editButton);

        //! bin element
        const binElement = document.createElement('div');
        binElement.className = 'bin hideinfront';
        binElement.innerHTML = '<img height="20px" width="20px" src="<?php echo plugin_dir_url( __DIR__).'assets/icons/bin.png'; ?>">';
        page.appendChild(binElement);

        //! updown arrow
        const upDownArrow = document.createElement('div');
        upDownArrow.className = 'up-down-arrow hideinfront';
        upDownArrow.innerHTML = '<img height="20px" width="20px" class="up-arrow" src="<?php echo plugin_dir_url( __DIR__).'assets/icons/up.png'; ?>"> <img height="20px" width="20px" class="down-arrow" src="<?php echo plugin_dir_url( __DIR__).'assets/icons/down.png'; ?>">';
        page.appendChild(upDownArrow);
        dropArea.appendChild(page);
        // dropArea.appendChild(newElement);
    }

    function createFormElement(type) {
        console.log('create form element', type);
        const element = document.createElement('div');
        element.className = 'dropped-element cfformselement';

        var titleCount = formBuilder.querySelectorAll('.form-title').length;
        var textboxCount = formBuilder.querySelectorAll('.form-textbox').length;
        var radioCount = formBuilder.querySelectorAll('.form-radio').length;
        var checkboxCount = formBuilder.querySelectorAll('.form-checkbox').length;
        var dropdownCount = formBuilder.querySelectorAll('.form-dropdown').length;
        var sectionDividerCount = formBuilder.querySelectorAll('.form-section-divider').length;
        var pageBreakCount = formBuilder.querySelectorAll('.form-page-break').length;
        switch (type) {
            case 'textbox':
                element.innerHTML = '<div class="form-group form-textbox" id="form-textbox-' + (textboxCount + 1) + '"><label>Textbox ' + (textboxCount + 1) + ':</label><input type="text"></div>';
                break;
            case 'radio':
                element.innerHTML = '<div class="form-group form-radio" id="form-radio-' + (radioCount + 1) + '"><label>Radio Button ' + (radioCount + 1) + ':</label></div>';
                break;
            case 'checkbox':
                element.innerHTML = '<div class="form-group form-checkbox" id="form-checkbox-' + (checkboxCount + 1) + '"><label>Checkbox ' + (checkboxCount + 1) + ':</label></div>';
                break;
            case 'title':
                element.innerHTML = '<h4 class="form-group form-title" id="form-title-' + (titleCount + 1) + '">Title ' + (titleCount + 1) + '</h4>';
                break;
            case 'dropdown':
                element.innerHTML = '<div class="form-group form-dropdown" id="form-dropdown-' + (dropdownCount + 1) + '"><label>Dropdown ' + (dropdownCount + 1) + ':</label></div>';
                break;
            case 'section-divider':
                element.innerHTML = '<div class="form-group form-section-divider" id="form-section-divider-' + (sectionDividerCount + 1) + '"><hr></div>';
                break;
            case 'page-break':
                element.innerHTML = '<div class="form-group form-page-break" id="form-page-break-' + (pageBreakCount + 1) + '"><hr></div>';
                break;
        }
        return element;
    }
});
</script>
