<?php
global $wpdb;
$form = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}cf_form_data WHERE id = " . $_GET['form_id']);

if (isset($_POST['submit'])) {
    $form_title = $_POST['form_title'];
    $submit_button_text = $_POST['submit_button_text'];
    $success_message = $_POST['success_message'];
    $error_message = $_POST['error_message'];
    $send_to_email = $_POST['send_to_email'];
    $email_subject = $_POST['email_subject'];
    $email_body = $_POST['email_body'];

    $wpdb->update(
        "{$wpdb->prefix}cf_form_data",
        array(
            'form_title' => $form_title,
            'submit_button_text' => $submit_button_text,
            'success_message' => $success_message,
            'error_message' => $error_message,
            'send_to_email' => $send_to_email,
            'email_subject' => $email_subject,
            'email_body' => $email_body
        ),
        array('id' => $form->id)
    );

    echo '<div class="alert alert-success">Form settings updated successfully.</div>';
    echo '<script>window.location.href = "' . admin_url('admin.php?page=custom-form-builder-settings&form_id=' . $form->id . '') . '";</script>';
}

?>
<div class="container">
    <div>
        <a href="<?php echo admin_url('admin.php?page=custom-form-builder-forms'); ?>" class="button button-primary">Back to Forms</a>
    </div>
    <form method="post" action="#">
        <input type="hidden" name="form_id" value="<?php echo $form->id; ?>">
        
        <div class="form-group">
            <label for="form_title">Form Title:</label>
            <input type="text" name="form_title" id="form_title" value="<?php echo $form->form_title; ?>">
        </div>
    
        <div class="form-group">
            <label for="submit_button_text">Submit Button Text</label>
            <input type="text" name="submit_button_text" id="submit_button_text" value="<?php echo $form->submit_button_text; ?>">
        </div>
    
        <div class="form-group">
            <label for="success_message">Success Message</label>
            <input type="text" name="success_message" id="success_message" value="<?php echo $form->success_message; ?>">
        </div>
    
        <div class="form-group">
            <label for="error_message">Error Message</label>
            <input type="text" name="error_message" id="error_message" value="<?php echo $form->error_message; ?>">
        </div>
    
        <div class="form-group">
            <label for="send_to_email">Send To Email Address</label>
            <input type="text" name="send_to_email" id="send_to_email" value="<?php echo $form->send_to_email; ?>">
        </div>
    
        <div class="form-group">
            <label for="email_subject">Email Subject Line</label>
            <input type="text" name="email_subject" id="email_subject" value="<?php echo $form->email_subject; ?>">
        </div>
    
        <div class="form-group">
            <label for="email_body">Email Body</label>
            <textarea name="email_body" id="email_body" cols="30" rows="10"><?php echo $form->email_body; ?></textarea>
        </div>
    
        <div class="form-group">
            <button type="submit" name="submit" class="btn-primary">Save</button>
        </div>
    </form>
</div>